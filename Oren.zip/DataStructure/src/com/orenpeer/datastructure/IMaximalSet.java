package com.orenpeer.datastructure;

import java.util.Set;

public interface IMaximalSet<T> {
	
	void add(T item);
	void remove(T item);
	long getValue(T item);
	Set<T> getMaxValues();

}
